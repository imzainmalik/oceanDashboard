<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts.family.includes.compatibility', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <meta name="description" content="">
    <title> Family Member </title>
    <?php echo $__env->make('layouts.family.includes.style', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>

    <div class="page-box">
        <?php echo $__env->make('layouts.family.includes.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="main-content">
            <?php echo $__env->make('layouts.family.includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <?php echo $__env->make('layouts.family.includes.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH D:\OceanDashboard\resources\views/layouts/family/layout.blade.php ENDPATH**/ ?>