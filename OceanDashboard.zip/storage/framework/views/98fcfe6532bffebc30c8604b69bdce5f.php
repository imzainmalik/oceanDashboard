

<?php if(auth()->user()->role->id == 5): ?>
    <?php echo $__env->make('layouts.caregiver.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php elseif(auth()->user()->role->id == 1): ?>
    <?php echo $__env->make('layouts.superadmin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php elseif(auth()->user()->role->id == 2): ?>
    <?php echo $__env->make('layouts.senior.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php elseif(auth()->user()->role->id == 3): ?>
    <?php echo $__env->make('layouts.family.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php elseif(auth()->user()->role->id == 4): ?>
    <?php echo $__env->make('layouts.family_owner.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>
<?php /**PATH D:\OceanDashboard\resources\views/layouts/app.blade.php ENDPATH**/ ?>