

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>💳 Payment Methods</h2>

    

    <?php if($methods->count()): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Brand</th>
                    <th>Last 4</th>
                    <th>Expiry</th>
                    <th>Primary</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($method->card_brand); ?></td>
                    <td>**** <?php echo e($method->card_last_four); ?></td>
                    <td><?php echo e($method->expiry_month); ?>/<?php echo e($method->expiry_year); ?></td>
                    <td>
                        <?php if($method->is_primary): ?>
                            <span class="badge bg-success">Primary</span>
                        <?php else: ?>
                            <form method="POST" action="<?php echo e(route('payment-methods.setPrimary', $method->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-sm btn-outline-info">Set Primary</button>
                            </form>
                        <?php endif; ?>
                    </td>
                    <td>
                        <form method="POST" action="<?php echo e(route('payment-methods.destroy', $method->id)); ?>">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" onclick="return confirm('Remove this card?')">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="text-muted">No cards added yet.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\OceanDashboard\resources\views/family_owner/payment_methods/index.blade.php ENDPATH**/ ?>