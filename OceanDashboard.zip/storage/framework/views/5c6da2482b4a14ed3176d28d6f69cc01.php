

<?php $__env->startSection('content'); ?>
    <form id="payment-form" action="<?php echo e(route('subscription.payment.store', ['price_id' => $request->price_id])); ?>"
        method="POST">
        <?php echo csrf_field(); ?>
        <div id="card-element"><!-- Stripe Card Element --></div>
        <button id="submit-btn">Subscribe</button>
        
        <div class="alert alert-danger" id="error-alert" style="display:none;"></div>

        <input type="hidden" name="type" value="<?php echo e($request->type); ?>"/>
        <input type="hidden" name="packge_price" value="<?php echo e($request->price_id); ?>"/>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="https://js.stripe.com/v3/"></script>
    <script>
        const stripe = Stripe("<?php echo e(env('STRIPE_KEY')); ?>");
        const elements = stripe.elements();
        const cardElement = elements.create('card');
        cardElement.mount('#card-element');

        const form = document.getElementById('payment-form');
        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            const {
                paymentMethod,
                error
            } = await stripe.createPaymentMethod({
                type: 'card',
                card: cardElement,
            });

            if (error) {
                const alert = document.getElementById('error-alert');
                alert.innerHTML = error.message;
                alert.style.display = "block";
            } else {
                // Debug: see what ID we got
                console.log("PaymentMethod ID:", paymentMethod.id);

                let hidden = document.createElement('input');
                hidden.type = 'hidden';
                hidden.name = 'payment_method';
                hidden.value = paymentMethod.id; // should look like pm_123456789
                form.appendChild(hidden);

                form.submit();
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\OceanDashboard\resources\views/subscription/payment.blade.php ENDPATH**/ ?>