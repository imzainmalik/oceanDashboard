

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>📊 Subscription Billing</h2>

    <a href="<?php echo e(route('payment-methods.index')); ?>">Payment method</a>
    <?php if($subscriptions->count()): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Plan</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Payment Gateway</th>
                    <th>Transaction</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(ucfirst($sub->plan)); ?></td>
                    <td>$<?php echo e(number_format($sub->amount, 2)); ?></td>
                    <td>
                        <span class="badge bg-<?php echo e($sub->status == 'active' ? 'success' : ($sub->status == 'expired' ? 'secondary' : 'danger')); ?>">
                            <?php echo e(ucfirst($sub->status)); ?>

                        </span>
                    </td>
                    <td><?php echo e($sub->start_date); ?></td>
                    <td><?php echo e($sub->end_date ?? '-'); ?></td>
                    <td><?php echo e(ucfirst($sub->payment_gateway)); ?></td>
                    <td><?php echo e($sub->transaction_id ?? '-'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="text-muted">No subscription records found.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\OceanDashboard\resources\views/family_owner/subscriptions/index.blade.php ENDPATH**/ ?>