<div class="list-group">
    <?php if(ucfirst($feature) != "Documents" || ucfirst($feature) != "Medical_docs" || ucfirst($feature) != "Insurance_docs" || ucfirst($feature) != "Emergency_docs"): ?>
    <div class="list-group-item d-flex justify-content-between align-items-center">
        <span>Insert <?php echo e(ucfirst($feature)); ?></span>
        <div class="form-check form-switch">
            <input class="form-check-input" type="checkbox" name="permissions[]" 
                   value="<?php echo e($feature); ?>_insert">
        </div>
    </div>

    <div class="list-group-item d-flex justify-content-between align-items-center">
        <span>Update <?php echo e(ucfirst($feature)); ?></span>
        <div class="form-check form-switch">
            <input class="form-check-input" type="checkbox" name="permissions[]" 
                   value="<?php echo e($feature); ?>_update">
        </div>
    </div>

    <div class="list-group-item d-flex justify-content-between align-items-center">
        <span>Delete <?php echo e(ucfirst($feature)); ?></span>
        <div class="form-check form-switch">
            <input class="form-check-input" type="checkbox" name="permissions[]" 
                   value="<?php echo e($feature); ?>_delete">
        </div>
    </div>
    <?php endif; ?>
    <div class="list-group-item d-flex justify-content-between align-items-center">
        <span><?php if(ucfirst($feature) == "Meetings"): ?> Join <?php else: ?> Show <?php endif; ?> <?php echo e(ucfirst($feature)); ?></span>
        <div class="form-check form-switch">
            <input class="form-check-input" type="checkbox" name="permissions[]" 
                   value="<?php if(ucfirst($feature) == "Meetings"): ?> <?php echo e($feature); ?>_join <?php else: ?> <?php echo e($feature); ?>_join <?php endif; ?>">
            
        </div>
    </div>
</div>
<?php /**PATH D:\OceanDashboard\resources\views/components/permissions.blade.php ENDPATH**/ ?>