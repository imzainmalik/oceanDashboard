

<?php $__env->startSection('content'); ?>
    <style>
        .fade:not(.show) {
            opacity: 1;
        }

        /* div#download_monthly {
                                            background-color: #0c0c0c9c;
                                        } */
    </style>
    <div class="container">
        <h5 class="mb-4">All Bill Requests</h5>

        <div class="card shadow">
            <a href="<?php echo e(route(''.auth()->user()->role->name.'.bills.create')); ?>" class="btn btn-primary">Create Bill</a>
            <div class="card-body">
                <table class="table table-striped table-hover align-middle">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Bill Title</th>
                            <th>Amount</th>
                            <th>Payer</th>
                            <th>Payment Method</th>
                            <th>Status</th>
                            <th>Receipt</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($bill->title); ?></td>
                                <td>$<?php echo e(number_format($bill->amount, 2)); ?></td>
                                <td><?php echo e($bill->assignee->name ?? 'N/A'); ?></td>
                                <td><?php echo e(ucfirst($bill->payment_method)); ?></td>
                                <td>
                                    <span
                                        class="badge 
                                    <?php if($bill->status === 'pending'): ?> bg-warning
                                    <?php elseif($bill->status === 'approved'): ?> bg-success
                                    <?php elseif($bill->status === 'declined'): ?> bg-danger
                                    <?php else: ?> bg-secondary <?php endif; ?>">
                                        <?php echo e(ucfirst($bill->status)); ?>

                                    </span>
                                </td>
                                
                                <td>
                                    <?php if($bill->payments->count() > 0): ?>
                                        <a href="<?php echo e(route('' . auth()->user()->custom_role . '.bills.show', $bill->id)); ?>"
                                            class="btn btn-sm btn-info">
                                            View Receipt
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted">Not Uploaded</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(auth()->user()->id === $bill->owner_id && $bill->status === 'pending'): ?>
                                        <form action="<?php echo e(route('familyOwner.bills.approve', $bill->id)); ?>" method="POST"
                                            class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <button class="btn btn-sm btn-success">Approve</button>
                                        </form>

                                        <form action="<?php echo e(route('familyOwner.bills.decline', $bill->id)); ?>" method="POST"
                                            class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <button class="btn btn-sm btn-danger">Decline</button>
                                        </form>
                                    <?php else: ?>
                                        <em class="text-muted">No Action</em>
                                    <?php endif; ?>

                                    <?php if(auth()->user()->id == $bill->assigned_to): ?>
                                        <button class="btn btn-primary" data-toggle="modal"
                                            data-target="#exampleModal_<?php echo e($bill->id); ?>">Submit Payment</button>
                                        <div class="modal fade" id="exampleModal_<?php echo e($bill->id); ?>" tabindex="-1"
                                            role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form method="POST"
                                                            action="<?php echo e(route('senior.bills.submitPayment', $bill->id)); ?>"
                                                            enctype="multipart/form-data">
                                                            <?php echo csrf_field(); ?>

                                                            <div class="mb-3">
                                                                <label for="amount" class="form-label">Payment
                                                                    Amount</label>
                                                                <input type="number" step="0.01" name="amount"
                                                                    id="amount" class="form-control"
                                                                    value="<?php echo e($bill->amount); ?>" required>
                                                            </div>

                                                            <div class="mb-3">
                                                                <label for="payment_method" class="form-label">Payment
                                                                    Method</label>
                                                                <select name="payment_method" id="payment_method"
                                                                    class="form-select" required>
                                                                    <option value="">-- Select Payment Method --
                                                                    </option>
                                                                    <option value="cashapp">Cash App</option>
                                                                    <option value="zelle">Zelle</option>
                                                                    <option value="paypal">PayPal</option>
                                                                    <option value="bank_transfer">Bank Transfer</option>
                                                                    <option value="other">Other</option>
                                                                </select>
                                                            </div>

                                                            <div class="mb-3">
                                                                <label for="transaction_id" class="form-label">Transaction
                                                                    ID (if available)</label>
                                                                <input type="text" name="transaction_id"
                                                                    id="transaction_id" class="form-control"
                                                                    placeholder="e.g. Bank Ref #12345">
                                                            </div>

                                                            <div class="mb-3">
                                                                <label for="receipt" class="form-label">Upload Receipt
                                                                    (Proof)
                                                                </label>
                                                                <input type="file" name="receipt" id="receipt"
                                                                    class="form-control" accept="image/*,.pdf">
                                                                <small class="text-muted">Upload a receipt or screenshot as
                                                                    proof of payment.</small>
                                                            </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">
                                                            Submit Payment
                                                        </button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted">No bills found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\OceanDashboard\resources\views/family_owner/bills/index.blade.php ENDPATH**/ ?>