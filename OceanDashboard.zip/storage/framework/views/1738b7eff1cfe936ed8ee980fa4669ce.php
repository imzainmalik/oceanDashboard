
<?php $__env->startSection('content'); ?>
    <div class="page-box py-4">
        <div class="card">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="card-header">
                Create Family members
            </div>

            <div class="card-body">
                <form method="post" action="<?php echo e(route(''.auth()->user()->custom_role.'.save_member')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <div class="col-6">
                            <label> Full name</label>
                            <input type="text" class="form-control" name="full_name" required />
                        </div>
                        <div class="col-6">
                            <label> Email</label>
                            <input type="email" class="form-control" name="email" required />
                        </div>

                        <div class="col-6">
                            <label> Password</label>
                            <input type="password" class="form-control" name="password" id="password" required />
                        </div>
                        <div class="col-6">
                            <label>Confirm Password</label>
                            <input type="password" class="form-control" name="cnfrm_password" id="confirm_password"
                                required />
                            <div class="invalid-feedback">Passwords do not match</div>
                        </div>
                        <div class="col-6">
                            <label> Display picture</label>
                            <input type="file" class="form-control" name="d_pic" id="d_pic" required />
                        </div>

                        <div class="col-6">
                            <label>Gender</label>
                            <select class="form-control" name="gender">
                                <option value="">-- Select --</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <label>Roles</label>
                            <select class="form-control" name="role" id="role" required>
                                <?php if(auth()->user()->custom_role != 'familyMember'): ?>
                                    <option value="4">Family Owner</option>
                                    <option value="3">Family Member</option>
                                    <option value="2">Senior</option>
                                <?php endif; ?>
                                <option value="5">Caregiver</option>
                            </select>
                        </div>


                        <div class="container mt-4">
                            <!-- Senior-specific fields -->
                            <div id="senior-fields" class="row mt-3 d-none">
                                <div class="col-6 mb-2">
                                    <label>Date of Birth</label>
                                    <input type="date" class="form-control" name="dob" required>
                                </div>
                                <div class="col-6 mb-2">
                                    <label>Medical Condition</label>
                                    <input type="text" class="form-control" name="medical_condition" required>
                                </div>
                                <div class="col-6 mb-2">
                                    <label>Blood Type</label>
                                    <select class="form-control" name="blood_type" id="blood_type" required>
                                        <option disabled selected>Select Blood Type</option>
                                        <option value="A+">A
                                            positive</option>
                                        <option value="A-">A
                                            negative</option>
                                        <option value="B-">B
                                            negative</option>
                                        <option value="B+">B
                                            positive</option>
                                        <option value="O+">O
                                            positive</option>
                                        <option value="O-">O
                                            negative</option>
                                        <option value="AB-">AB
                                            negative</option>
                                        <option value="AB+">AB
                                            positive</option>
                                    </select>
                                </div>
                                <div class="col-6 mb-2">
                                    <label>Primary Doctor</label>
                                    <input type="text" class="form-control" name="primary_doctor" required>
                                </div>
                                <div class="col-6 mb-2">
                                    <label>Emergency Contact Name</label>
                                    <input type="text" class="form-control" name="emergency_contact_name" required>
                                </div>
                                <div class="col-6 mb-2">
                                    <label>Emergency Contact Phone</label>
                                    <input type="text" class="form-control" name="emergency_contact_phone" required>
                                </div>
                                <div class="col-6 mb-2 form-check">
                                    <input class="form-check-input" type="checkbox" value="1" name="has_dementia"
                                        id="has_dementia">
                                    <label class="form-check-label" for="has_dementia">Has Dementia</label>
                                </div>
                                <div class="col-6 mb-2 form-check">
                                    <input class="form-check-input" type="checkbox"value="1" name="has_alzheimer"
                                        id="has_alzheimer">
                                    <label class="form-check-label" for="has_alzheimer">Has Alzheimer</label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr>

                    <div class="container mt-4">
                        <h3 class="mb-4">⚙️ Setup Permissions</h3>

                        
                        <div class="card">
                            <div class="card-header">
                                <ul class="nav nav-tabs" id="permissionTabs" role="tablist">
                                    <?php
                                        $modules = [
                                            'Bills' => 'bills',
                                            'Documents' => 'documents',
                                            'Caregivers' => 'caregivers',
                                            'Reports' => 'reports',
                                            'Daily Tasks and Care logs' => 'tasks',
                                            'Family Members' => 'members',
                                            // 'Subscription' => 'subscription',
                                            'Notes & Wellness' => 'notes',
                                            'Meetings' => 'meetings',
                                            'Voting Pools' => 'pools',
                                            'Seniors' => 'seniors',
                                            // 'Caregiver Special' => 'caregiver',
                                            // 'Admin' => 'admin',
                                        ];
                                    ?>

                                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="nav-item">
                                            <a class="nav-link <?php if($loop->first): ?> active <?php endif; ?>"
                                                id="<?php echo e($id); ?>-tab" data-bs-toggle="tab"
                                                href="#<?php echo e($id); ?>" role="tab"><?php echo e($label); ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>

                            <div class="card-body">
                                <div class="tab-content" id="permissionTabsContent">

                                    
                                    <div class="tab-pane fade show active" id="bills" role="tabpanel">
                                        <?php echo $__env->make('components.permissions', ['feature' => 'bills'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        <?php echo $__env->make('components.permissions', ['feature' => 'bill_payments'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        <?php echo $__env->make('components.permissions', ['feature' => 'contributions'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        <?php echo $__env->make('components.permissions', ['feature' => 'reimbursements'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        <div class="mt-3"><span class="badge bg-info">shortfall_tracking_show</span>
                                        </div>
                                    </div>

                                    
                                    <div class="tab-pane fade" id="documents" role="tabpanel">
                                        <?php echo $__env->make('components.permissions', ['feature' => 'documents'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        <?php echo $__env->make('components.permissions', ['feature' => 'medical_docs'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        <?php echo $__env->make('components.permissions', ['feature' => 'insurance_docs'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        <?php echo $__env->make('components.permissions', ['feature' => 'emergency_docs'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    </div>

                                    
                                    <div class="tab-pane fade" id="caregivers" role="tabpanel">
                                        <?php echo $__env->make('components.permissions', ['feature' => 'caregivers'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        <div class="mt-3">
                                            <span class="badge bg-info">User can only manage details of care givers, can't Assign different role</span> 
                                        </div>
                                    </div>

                                    
                                    <div class="tab-pane fade" id="reports" role="tabpanel">
                                        <?php echo $__env->make('components.permissions', ['feature' => 'reports'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    </div>

                                    
                                    <div class="tab-pane fade" id="tasks" role="tabpanel">
                                        <?php echo $__env->make('components.permissions', ['feature' => 'tasks'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        
                                    </div>

                                    
                                    <div class="tab-pane fade" id="members" role="tabpanel">
                                        <?php echo $__env->make('components.permissions', ['feature' => 'members'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        <div class="mt-3">
                                            <span class="badge bg-info">permissions_assign</span>
                                            <span class="badge bg-info">permissions_update</span>
                                            <span class="badge bg-info">permissions_delete</span>
                                            <span class="badge bg-info">permissions_show</span>
                                        </div>
                                    </div>

                                    
                                    

                                    
                                    <div class="tab-pane fade" id="notes" role="tabpanel">
                                        <?php echo $__env->make('components.permissions', ['feature' => 'family_notes'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        
                                        
                                    </div>

                                    
                                    <div class="tab-pane fade" id="meetings" role="tabpanel">
                                        <?php echo $__env->make('components.permissions', ['feature' => 'meetings'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        
                                        
                                    </div>

                                    
                                    <div class="tab-pane fade" id="pools" role="tabpanel">
                                        <?php echo $__env->make('components.permissions', ['feature' => 'pools'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        <div class="mt-3">
                                            <span class="badge bg-info">votes_cast</span>
                                            <span class="badge bg-info">votes_view</span>
                                        </div>
                                    </div>

                                    
                                    <div class="tab-pane fade" id="seniors" role="tabpanel">
                                        <?php echo $__env->make('components.permissions', ['feature' => 'daily_updates'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        <div class="mt-3">
                                            <span class="badge bg-info">notifications_update</span>
                                            <span class="badge bg-info">notifications_show</span>
                                            <span class="badge bg-info">profile_update</span>
                                            <span class="badge bg-info">profile_show</span>
                                        </div>
                                    </div>

                                    
                                    <div class="tab-pane fade" id="caregiver" role="tabpanel">
                                        <div class="mt-3">
                                            <span class="badge bg-info">activity_timeline_show</span>
                                            <span class="badge bg-info">emergency_protocol_show</span>
                                        </div>
                                    </div>

                                    
                                    

                                </div>
                            </div>
                        </div>

                    </div>

                    <br>
                    <button class="btn btn-primary" type="submit" id="registerForm">Submit</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        document.getElementById('role').addEventListener('change', function() {
            let seniorFields = document.getElementById('senior-fields');
            let inputs = seniorFields.querySelectorAll('input, select, textarea');

            if (this.value === "2") { // Senior selected
                seniorFields.classList.remove('d-none');
                inputs.forEach(input => input.setAttribute('required', true));
            } else {
                seniorFields.classList.add('d-none');
                inputs.forEach(input => input.removeAttribute('required'));
            }
        });

        $('#registerForm').click(function(e) {
            // e.preventDefault();
            const pass = document.getElementById('password');
            const confirmPass = document.getElementById('confirm_password');
            // console.log(pass.value, confirmPass.value);
            if (pass.value !== confirmPass.value) {
                e.preventDefault(); // stop form submission
                confirmPass.classList.add('is-invalid');
            } else {
                confirmPass.classList.remove('is-invalid');
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\OceanDashboard\resources\views/family_owner/family_member/create.blade.php ENDPATH**/ ?>