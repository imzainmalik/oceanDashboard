<?php echo $__env->make('layouts.caregiver.includes.var', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>;
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0" /><?php /**PATH D:\OceanDashboard\resources\views/layouts/family_owner/includes/compatibility.blade.php ENDPATH**/ ?>