<footer>
    <div class="container-fluid p-0">
        <div class="copyright">
            <div class="row align-items-center">
                <div class="col-lg-12 text-center">
                    <p class="text-white">Copyright @ <script>
                            var CurrentYear = new Date().getFullYear()
                            document.write(CurrentYear)
                        </script> All Rights Reserved.</p>
                </div>
            </div>

        </div>
    </div> 
</footer>


 
